﻿using UnityEngine;
using System.Collections;

public class Lives : MonoBehaviour {
	public Texture Life1;
	public Texture Life2;
	public Texture Life3;

	

	void OnGUI() {
		GUI.DrawTexture (new Rect (10, 500, 100, 100), Life1);
		GUI.DrawTexture (new Rect (110, 500, 100, 100), Life2);
		GUI.DrawTexture (new Rect (210, 500, 100, 100), Life3);
	}
}

//script i pacmanmovement
//public GameObject pacman;

//private int currentLife = 0;
/*void OnCollisionEnter (Collider col) {

	if(col.gameObject.name = "teleport1"){
		pacman.transform.position = spawnDestination1.transform.position;
	}

	if(col.gameObject.name = "ghost"){
		if(currentLife = 3){
			Getcomponent<Lives>.Life3 = null;
			currentLife -= 1;
		}
		if(currentLife = 2){
			Getcomponent<Lives>.Life2 = null;
			currentLife -= 1;
		}
		if(currentLife = 1){
			Getcomponent<Lives>.Life1 = null;
			Application.Loadlevel("YouLost");
		}
	}


}*/