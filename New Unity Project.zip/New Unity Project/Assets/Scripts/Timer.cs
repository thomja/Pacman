﻿using UnityEngine;
using System.Collections;

public class Timer : MonoBehaviour {

	public Rect timerPosition;
	public float startTime = 10;
	public GUISkin guiSkin;
	private string currentTime;
	private float timePoints;
	private bool updateTimer = false;

	void Start(){
		updateTimer = true;
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (updateTimer == true) 
		{
			startTime -= Time.deltaTime;
			currentTime = string.Format ("{0:0.0}", startTime);
		}
		//spelaren förlora på tid
		if (startTime <= 0) {
			startTime = 0;//-> så att den timern räknar inte längre
			currentTime = "";//->gör så att timern försvinner när den är 0
			//GameOverTryAgain(); i metoden GameOverTryAgain ha en if-sats "click on R restart" GUI + Application.LoadLevel()? 
			//GetComponent lifescript -1 life
		}
	}
	

		/*	när pacman har ätit alla mat och powerups, timePoitns räknas.
		 * if (GetComponent<Points>.matPoints == 500 && GetComponent<Points>.powerUpPoints) {
			updateTimer = false;
			timePoints = Mathf.Round(startTime) * 10;
			currentTime = "";
			Application.Loadlevel(2) //nästa level som blir svårare, eller gör en metod om man vill starta nästa level
		}*/

	void OnGUI()
	{
		GUI.skin = guiSkin;
		GUI.Label (timerPosition, currentTime);
	}
}
